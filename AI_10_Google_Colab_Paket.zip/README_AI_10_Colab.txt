AI 10 - Google Colab variant

1. Google Colab ac.
2. File > Upload notebook sec ve AI_10_Google_Colab.ipynb faylini yukle.
3. Xanaları yuxarıdan aşağıya isle.
4. Ilk ise salinmada housing_az_realistic.csv olmadigi ucun notebook demo dataset yaradir.
5. Oz real housing_az_realistic.csv faylini esas dataset kimi yuklemek ucun butun xanalar isledikden sonra upload_main_dataset() funksiyasini cagir.
6. Tek menzil elavesi, CSV importu, proqnoz ve Retrain formalarindan istifade et.

CSV sutunlari: PriceAZN,Bedrooms,Bathrooms,Sqm,City
Dataset: AI 10/data/housing_az_realistic.csv
Model: AI 10/models/models_az.pkl

Qeyd: Demo CSV yalniz notebook-u yoxlamaq ucundur, real bazar melumatlari deyil. ZIP arxivinde esas housing_az_realistic.csv olmadigina gore demo melumatlar elave olunub.

Colab variantinda React, ASP.NET Core ve FastAPI serverleri qurulmur. Tapshiriqin melumat emali, yoxlama, CSV elavesi ve modelin yeniden oyredilmesi funksiyalari notebook daxilinde Python funksiyalari ve interaktiv formalarla yerine yetirilir.
